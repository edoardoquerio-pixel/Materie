#include <stdio.h>
#include "biglietti.h"

int cercaBiglietto(Biglietto biglietti[], int nBiglietti, int fila, int posto) {
    for (int i = 0; i < nBiglietti; i++) {
        if (biglietti[i].fila == fila && biglietti[i].posto == posto) {
            return i;
        }
    }
    return -1;
}

int aggiungiBiglietto(Biglietto biglietti[], int *nBiglietti, int fila, int posto, float prezzo) {
    if (*nBiglietti >= MAX_BIGLIETTI) {
        return 0;
    }
    biglietti[*nBiglietti].fila = fila;
    biglietti[*nBiglietti].posto = posto;
    biglietti[*nBiglietti].prezzo = prezzo;
    (*nBiglietti)++;
    return 1;
}

int rimuoviBiglietto(Biglietto biglietti[], int *nBiglietti, int fila, int posto, float *prezzoRimborso) {
    int indice = cercaBiglietto(biglietti, *nBiglietti, fila, posto);
    if (indice == -1) {
        return 0;
    }

    *prezzoRimborso = biglietti[indice].prezzo;

    for (int i = indice; i < *nBiglietti -1; i++) {
        biglietti[i] = biglietti[i+1];
    }

    (*nBiglietti)--;
    return 1;
}

void prenotaPosto(int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int *nBiglietti, float *incassoTotale) {
    char conferma;

    int fila = leggiIntero("Inserisci fila (0-9)");
    int posto = leggiIntero("Inserisci posto (0-11)");

    if (!posizioneValida(fila, posto)) {
        printf("Posizione non valida.\n");
        return;
    }

    if (sala[fila][posto] == 1) {
        printf("Posto gia' occupato\n");
        return;
    }

    float prezzo = calcolaPrezzo(fila);

    printf(("Acquistare 1 biglietto al prezzo di %.2f euro? (S/N) "), prezzo);
    scanf(" %c", &conferma);

    if (conferma == 'S' || conferma == 's') {
        if (aggiungiBiglietto(biglietti, nBiglietti, fila, posto, prezzo)) {
            sala[fila][posto] = 1;
            *incassoTotale += prezzo;
            printf("Operazione completata con successo!\n Grazie per la tua prenotazione!\n Biglietto fila [%d], posto [%d] acquistato al prezzo di euro %.2f\n", fila, posto, prezzo);
        } else {
            printf("Biglietto non acquistabile, sala in overbooking\n");
        }
    } else {
        printf("Operazione Annullata\n");
    }
}

void annullaPrenotazione(int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int *nBiglietti, float *incassoTotale) {

    float rimborso;

    int fila = leggiIntero("Inserisci fila (0-9)");
    int posto = leggiIntero("Inserisci posto (0-11)");

    if (!posizioneValida(fila, posto)) {
        printf("Posizione non valida.\n");
        return;
    }

    if (sala[fila][posto] == 0) {
        printf("Il posto risulta gia' libero\n");
        return;
    }

    if (rimuoviBiglietto(biglietti, nBiglietti, fila, posto, &rimborso)) {
        sala[fila][posto] = 0;
        *incassoTotale -= rimborso;
        printf("Operazione eseguita con successo!\n Prenotazione annullata e rimborso di euro %.2f effettuato.\n", rimborso);
    } else {
        printf("Errore! Biglietto non trovato\n");
    }

}