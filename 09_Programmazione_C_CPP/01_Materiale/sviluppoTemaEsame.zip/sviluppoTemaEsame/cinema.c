#include <stdio.h>
#include "cinema.h"

void inizializzaSala(int sala[FILE_SALA][POSTI_PER_FILA]) {
    for (int i = 0; i < FILE_SALA; i++) {
        for (int j = 0; j < POSTI_PER_FILA; j++) {
            sala[i][j] = 0;
        }
    }
}

void mostraSala(int sala[FILE_SALA][POSTI_PER_FILA]) {
    printf(TITOLO_SALA);
    printf(" POSTO:   ");
    for (int j = 0; j < POSTI_PER_FILA; j++) {
        printf("%3d ", j);
    }
    printf("\n");

    printf(SEPARATORE_FILE);
    for (int i = 0; i < FILE_SALA; i++) {
        printf("Fila %d: | ", i);
        for (int j = 0; j < POSTI_PER_FILA; j++) {
            printf("%3d ", sala[i][j]);
        }
        printf(" |\n");
    }
    printf(SEPARATORE_FILE);
}

int leggiIntero(const char *messaggio) {
    int valore;
    int esito;
    do {
        printf("%s", messaggio);
        esito = scanf("%d", &valore);
        if (esito != 1) {
            printf("Input non valido. Inserire un numero intero.\n");
            // svuoto il buffer di input fino al newline
            while (getchar() != '\n');
        }
    } while (esito != 1);
    // svuoto il buffer di input fino al newline
    while (getchar() != '\n');
    return valore;
}

int posizioneValida(int fila, int posto) {
    return (fila >= 0 && fila < FILE_SALA && posto >= 0 && posto < POSTI_PER_FILA);
}

float calcolaPrezzo(int fila) {
    if (fila >=0 && fila <= 2) {
        return 10.0f;
    }
    return 7.0f;
}

void mostraStatistiche(int sala[FILE_SALA][POSTI_PER_FILA], int nBiglietti, float incassoTotale) {
    int occupati = 0;
    int liberi = 0;
    int totale = FILE_SALA * POSTI_PER_FILA;
    float percentuale;

    for (int i=0; i<FILE_SALA; i++) {
        for (int j=0; j<POSTI_PER_FILA; j++) {
            if (sala[i][j] == 1) {
                occupati++;
            } else {
                liberi++;
            }
        }
    }
    percentuale = occupati * 100.0f / totale;

    printf("\n==== STATISTICHE ====\n");
    printf("Posti liberi: %d\n", liberi);
    printf("Posti occupati: %d\n", occupati);
    printf("Percentuale occupazione: %.2f%%\n", percentuale);
    printf("Incasso totale: %.2f euro\n" , incassoTotale);
    printf("Biglietti venduti: %d\n", nBiglietti);
    printf("=====================\n");
}