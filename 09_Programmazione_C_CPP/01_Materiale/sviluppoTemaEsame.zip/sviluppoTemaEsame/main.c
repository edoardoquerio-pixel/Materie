#include <stdio.h>
#include "cinema.h"
#include "biglietti.h"
#include "file_manager.h"


/* menu, ciclo principale e coordinamento del programma */
int main(void) {

    int sala[FILE_SALA][POSTI_PER_FILA];
    Biglietto biglietti[MAX_BIGLIETTI];
    int nBiglietti = 0;
    float incassoTotale = 0.0f;
    int scelta;

    inizializzaSala(sala);
   // mostraSala(sala);
   // mostraStatistiche(sala, nBiglietti, incassoTotale);

    do {
        printf("\n===== MENU CINEMA =====\n");
        printf("1. Mostra sala\n");
        printf("2. Prenota posto e acquista biglietto\n");
        printf("3. Annulla prenotazione e ottieni rimborso\n");
        printf("4. Mostra statistiche\n");
        printf("5. Salva sala e biglietti\n");
        printf("6. Carica sala e biglietti\n");

        printf("0. Esci\n");

        scelta = leggiIntero("Scelta: ");

        switch (scelta) {
            case 1:
                mostraSala(sala);
                break;
            case 2:
                prenotaPosto(sala, biglietti, &nBiglietti, &incassoTotale);
                break;
            case 3:
                annullaPrenotazione(sala, biglietti, &nBiglietti, &incassoTotale);
                break;
            case 4:
                mostraStatistiche(sala, nBiglietti, incassoTotale);
                break;
            case 5:
                if (salvaDati("cinema.txt", sala, biglietti, nBiglietti, incassoTotale)) {
                    printf("Dati salvati correttamente.\n");
                } else {
                    printf("Errore durante il salvataggio.\n");
                }
                break;
            case 6:
                if (caricaDati("cinema.txt", sala, biglietti, &nBiglietti, &incassoTotale)) {
                    printf("Dati caricati correttamente.\n");
                } else {
                    printf("Errore durante il caricamento.\n");
                }
                break;

            case 0:
                printf("Uscita dal Programma. Grazie e arrivederci!\n");
                break;
            default:
                printf("Scelta non valida!\n");
        }
    } while(scelta != 0);

    return 0;    return 0;
}