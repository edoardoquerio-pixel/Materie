/* salvataggio e caricamento dei dati */
#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

#include "biglietti.h"

int salvaDati(const char *nomeFile, int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int nBiglietti, float incassoTotale);

int caricaDati(const char *nomeFile, int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int *nBiglietti, float *incassoTotale);


#endif
