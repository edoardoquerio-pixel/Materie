#include <stdio.h>
#include "file_manager.h"

int salvaDati(const char *nomeFile, int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int nBiglietti, float incassoTotale) {
    FILE *fp;

    fp = fopen(nomeFile, "w");
    if (fp == NULL) {
        return 0;
    }

    fprintf(fp, "%d %d\n", FILE_SALA, POSTI_PER_FILA);

    for (int i = 0; i < FILE_SALA; i++) {
        for (int j = 0; j < POSTI_PER_FILA; j++) {
            fprintf(fp, "%d ", sala[i][j]);
        }
        fprintf(fp, "\n");
    }

    fprintf(fp, "%d\n", nBiglietti);

    for (int i = 0; i < nBiglietti; i++) {
        fprintf(fp, "%d %d %.2f\n",
            biglietti[i].fila,
            biglietti[i].posto,
            biglietti[i].prezzo);
    }

    fprintf(fp, "%.2f\n", incassoTotale);

    fclose(fp);
    return 1;
}

int caricaDati(const char *nomeFile, int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int *nBiglietti, float *incassoTotale) {
    FILE *fp;
    int righe, colonne;
    fp = fopen(nomeFile, "r");
    if (fp == NULL) {
        return 0;
    }
    if (fscanf(fp, "%d %d", &righe, &colonne) != 2) {
        fclose(fp);
        return 0;
    }
    if (righe != FILE_SALA || colonne != POSTI_PER_FILA) {
        fclose(fp);
        return 0;
    }
    for (int i = 0; i < FILE_SALA; i++) {
        for (int j = 0; j < POSTI_PER_FILA; j++) {
            if (fscanf(fp, "%d", &sala[i][j]) != 1) {
                fclose(fp);
                return 0;
            }
        }
    }

    if (fscanf(fp, "%d", nBiglietti) != 1) {
        fclose(fp);
        return 0;
    }

    for (int i = 0; i < *nBiglietti; i++) {
        if (fscanf(fp, "%d %d %f",
                   &biglietti[i].fila,
                   &biglietti[i].posto,
                   &biglietti[i].prezzo) != 3) {
            fclose(fp);
            return 0;
        }
    }

    if (fscanf(fp, "%f", incassoTotale) != 1) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    return 1;
}

