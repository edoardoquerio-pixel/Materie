/* struct Biglietto, ricerca, aggiunta, rimozione, prenotazione e annullamento */
#ifndef BIGLIETTI_H
#define BIGLIETTI_H

#include "cinema.h"
#define MAX_BIGLIETTI (FILE_SALA * POSTI_PER_FILA)

typedef struct {
    int fila;
    int posto;
    float prezzo;
} Biglietto;

int cercaBiglietto(Biglietto biglietti[], int nBiglietti, int fila, int posto);

int aggiungiBiglietto(Biglietto biglietti[], int *nBiglietti, int fila, int posto, float prezzo);

int rimuoviBiglietto(Biglietto biglietti[], int *nBiglietti, int fila, int posto, float *prezzoRimborso);

void prenotaPosto(int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int *nBiglietti, float *incassoTotale);

void annullaPrenotazione(int sala[FILE_SALA][POSTI_PER_FILA], Biglietto biglietti[], int *nBiglietti, float *incassoTotale);


#endif
