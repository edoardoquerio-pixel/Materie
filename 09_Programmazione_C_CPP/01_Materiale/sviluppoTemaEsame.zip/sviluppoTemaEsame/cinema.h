/* costanti della sala, input robusto, inizializzazione, stampa, validazione posizione, calcolo prezzo e statistiche */

#ifndef CINEMA_H
#define CINEMA_H

#define FILE_SALA 10
#define POSTI_PER_FILA 12
#define TITOLO_SALA "====================== SALA CINEMA =========================\n"
#define SEPARATORE_FILE "        ----------------------------------------------------\n"

// metodi per inizializzare e visualizzare la sala
void inizializzaSala(int sala[FILE_SALA][POSTI_PER_FILA]);
void mostraSala(int sala[FILE_SALA][POSTI_PER_FILA]);

int leggiIntero(const char *messaggio);
int posizioneValida(int fila, int posto);
float calcolaPrezzo(int fila);

void mostraStatistiche(int sala[FILE_SALA][POSTI_PER_FILA], int nBiglietti, float incassoTotale);



#endif
