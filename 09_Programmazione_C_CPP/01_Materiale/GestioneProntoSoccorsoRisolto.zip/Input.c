#include <stdio.h>
#include "input.h"

void leggiStringa(const char *prompt, char *dest, int maxLen) {
    printf("%s", prompt);
    scanf("%49s", dest);
    dest[maxLen - 1] = '\0';
    /* Svuota il resto della riga */
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int leggiIntero(const char *prompt) {
    int val;
    printf("%s", prompt);
    while (scanf("%d", &val) != 1) {
        printf("Input non valido. Riprova: ");
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
    }
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
    return val;
}