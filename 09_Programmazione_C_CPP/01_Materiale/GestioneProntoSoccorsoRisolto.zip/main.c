#include <stdio.h>
#include "paziente.h"
#include "persistenza.h"
#include "input.h"
#include "menu.h"

int main(void) {
    Paziente lista[MAX_PAZIENTI];
    int n = 0;

    /* Tenta caricamento automatico all'avvio */
    int caricati = caricaDati(lista, MAX_PAZIENTI, FILE_DATI);
    if (caricati > 0) n = caricati;

    int scelta;
    do {
        stampaMenu();
        scelta = leggiIntero("");

        switch (scelta) {
            case 1: menuRegistra(lista, &n);        break;
            case 2: menuChiamaPaziente(lista, n);   break;
            case 3: menuFineVisita(lista, n);        break;
            case 4: stampaListaAttesa(lista, n);     break;
            case 5: stampaStatistiche(lista, n);     break;
            case 6: salvaDati(lista, n, FILE_DATI);  break;
            case 7: {
                int c = caricaDati(lista, MAX_PAZIENTI, FILE_DATI);
                if (c >= 0) n = c;
                break;
            }
            case 0:
                printf("Salvataggio automatico in uscita...\n");
                salvaDati(lista, n, FILE_DATI);
                printf("Arrivederci.\n");
                break;
            default:
                printf("Scelta non valida.\n");
        }
    } while (scelta != 0);

    return 0;
}