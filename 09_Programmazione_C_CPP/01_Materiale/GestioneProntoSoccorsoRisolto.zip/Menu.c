#include <stdio.h>
#include "menu.h"
#include "input.h"
#include "triage.h"
#include "paziente.h"

void stampaMenu(void) {
    printf("\n----------------------------------------\n");
    printf("|     GESTIONE PRONTO SOCCORSO         |\n");
    printf("|--------------------------------------|\n");
    printf("|  1. Registra nuovo paziente          |\n");
    printf("|  2. Chiama prossimo paziente         |\n");
    printf("|  3. Registra fine visita             |\n");
    printf("|  4. Lista d'attesa (per priorita')   |\n");
    printf("|  5. Statistiche                      |\n");
    printf("|  6. Salva dati su file               |\n");
    printf("|  7. Carica dati da file              |\n");
    printf("|  0. Esci                             |\n");
    printf("----------------------------------------\n");
    printf("Scelta: ");
}

void menuRegistra(Paziente lista[], int *n) {
    char cognome[50], nome[50];
    leggiStringa("Cognome: ", cognome, 50);
    leggiStringa("Nome: ", nome, 50);

    printf("Codice triage:\n");
    printf("  1 = ROSSO     (immediato)\n");
    printf("  2 = ARANCIONE (15 min)\n");
    printf("  3 = GIALLO    (60 min)\n");
    printf("  4 = VERDE     (120 min)\n");
    int codice = leggiIntero("Codice: ");

    int ora    = leggiIntero("Ora arrivo (0-23): ");
    int minuto = leggiIntero("Minuto arrivo (0-59): ");

    registraPaziente(lista, n, cognome, nome, codice, ora, minuto);
}

void menuChiamaPaziente(Paziente lista[], int n) {
    int idx = chiamaPaziente(lista, n);
    if (idx == -1) return;

    char risposta[4];
    leggiStringa("Registrare subito la fine visita? (s/n): ", risposta, 4);
    if (risposta[0] == 's' || risposta[0] == 'S') {
        int oraFine    = leggiIntero("Ora fine visita (0-23): ");
        int minutoFine = leggiIntero("Minuto fine visita (0-59): ");
        registraFineVisita(lista, n, idx, oraFine, minutoFine);
    }
}

void menuFineVisita(Paziente lista[], int n) {
    if (n == 0) {
        printf("Nessun paziente registrato.\n");
        return;
    }

    printf("\nPazienti in attesa:\n");
    int trovati = 0;
    for (int i = 0; i < n; i++) {
        if (!lista[i].visitato) {
            printf("  [%d] %s %s (%s) - arrivo %02d:%02d\n",
                   i + 1,
                   lista[i].nome, lista[i].cognome,
                   nomeColore(lista[i].codice),
                   lista[i].oraArrivo, lista[i].minutoArrivo);
            trovati++;
        }
    }
    if (trovati == 0) {
        printf("Nessun paziente in attesa.\n");
        return;
    }

    int scelta = leggiIntero("Numero paziente da visitare: ");
    scelta--;   /* converti in indice 0-based */

    int oraFine    = leggiIntero("Ora fine visita (0-23): ");
    int minutoFine = leggiIntero("Minuto fine visita (0-59): ");
    registraFineVisita(lista, n, scelta, oraFine, minutoFine);
}