#ifndef INPUT_H
#define INPUT_H

/* Legge una stringa senza spazi, svuotando il buffer */
void leggiStringa(const char *prompt, char *dest, int maxLen);

/* Legge un intero, gestendo input non validi con loop di recupero */
int leggiIntero(const char *prompt);

#endif