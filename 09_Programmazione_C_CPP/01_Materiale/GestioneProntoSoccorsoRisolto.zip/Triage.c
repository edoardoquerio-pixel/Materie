#include <stdio.h>
#include "triage.h"

int tempoMassimoAttesa(int codice) {
    switch (codice) {
        case 1: return 0;
        case 2: return 15;
        case 3: return 60;
        case 4: return 120;
        default: return -1;
    }
}

int calcolaDurata(int oraIn, int minIn, int oraOut, int minOut) {
    return (oraOut * 60 + minOut) - (oraIn * 60 + minIn);
}

int prossimoPaziente(Paziente lista[], int n) {
    int bestIndex = -1;
    int bestCodice = 5; /* peggiore possibile */

    for (int i = 0; i < n; i++) {
        if (!lista[i].visitato && lista[i].codice < bestCodice) {
            bestCodice = lista[i].codice;
            bestIndex  = i;
        }
    }
    return bestIndex;
}

int chiamaPaziente(Paziente lista[], int n) {
    int idx = prossimoPaziente(lista, n);

    if (idx == -1) {
        printf("Nessun paziente in attesa.\n");
        return -1;
    }

    Paziente *p = &lista[idx];
    printf("\n>>> CHIAMATA PAZIENTE <<<\n");
    printf("    Nome    : %s %s\n", p->nome, p->cognome);
    printf("    Codice  : %s\n", nomeColore(p->codice));
    printf("    Arrivo  : %02d:%02d\n", p->oraArrivo, p->minutoArrivo);
    printf("Paziente pronto per la visita (indice interno: %d).\n\n", idx + 1);

    return idx;
}

void registraFineVisita(Paziente lista[], int n, int index, int oraFine, int minutoFine) {
    if (index < 0 || index >= n) {
        printf("Indice paziente non valido.\n");
        return;
    }

    Paziente *p = &lista[index];

    if (p->visitato) {
        printf("Attenzione: il paziente %s %s e' gia' stato visitato.\n",
               p->nome, p->cognome);
        return;
    }
    if (oraFine < 0 || oraFine > 23 || minutoFine < 0 || minutoFine > 59) {
        printf("Orario di fine non valido.\n");
        return;
    }

    int durata = calcolaDurata(p->oraArrivo, p->minutoArrivo, oraFine, minutoFine);
    if (durata < 0) {
        printf("Errore: l'ora di fine precede l'ora di arrivo.\n");
        return;
    }

    p->oraFine     = oraFine;
    p->minutoFine  = minutoFine;
    p->visitato    = 1;

    int massimo = tempoMassimoAttesa(p->codice);

    printf("\nVisita registrata per %s %s (%s).\n",
           p->nome, p->cognome, nomeColore(p->codice));
    printf("Durata attesa: %d minuti  |  Massimo previsto: %d minuti\n",
           durata, massimo);

    if (massimo == 0 && durata > 0) {
        printf("*** AVVISO: Il paziente ROSSO ha atteso %d min - doveva essere immediato! ***\n",
               durata);
    } else if (durata > massimo) {
        printf("*** AVVISO: Tempo d'attesa superato di %d minuti! ***\n",
               durata - massimo);
    } else {
        printf("Visita nei tempi previsti.\n");
    }
}