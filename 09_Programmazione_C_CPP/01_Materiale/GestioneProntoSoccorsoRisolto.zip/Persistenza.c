#include <stdio.h>
#include "persistenza.h"

int salvaDati(const Paziente lista[], int n, const char *nomeFile) {
    FILE *f = fopen(nomeFile, "wb");
    if (!f) {
        printf("Errore: impossibile aprire il file '%s' in scrittura.\n", nomeFile);
        return 0;
    }

    /* Prima scrivi il numero di pazienti */
    fwrite(&n, sizeof(int), 1, f);
    /* Poi scrivi tutti i record */
    fwrite(lista, sizeof(Paziente), n, f);

    fclose(f);
    printf("Dati salvati: %d pazient%s su '%s'.\n",
           n, n == 1 ? "e" : "i", nomeFile);
    return 1;
}

int caricaDati(Paziente lista[], int maxN, const char *nomeFile) {
    FILE *f = fopen(nomeFile, "rb");
    if (!f) {
        printf("File '%s' non trovato. Si parte con lista vuota.\n", nomeFile);
        return 0;
    }

    int n = 0;
    fread(&n, sizeof(int), 1, f);

    if (n < 0 || n > maxN) {
        printf("Errore: numero pazienti non valido nel file (%d).\n", n);
        fclose(f);
        return -1;
    }

    int letti = (int)fread(lista, sizeof(Paziente), n, f);
    fclose(f);

    if (letti != n) {
        printf("Attenzione: attesi %d record, letti %d.\n", n, letti);
        return letti;
    }

    printf("Dati caricati: %d pazient%s da '%s'.\n",
           n, n == 1 ? "e" : "i", nomeFile);
    return n;
}