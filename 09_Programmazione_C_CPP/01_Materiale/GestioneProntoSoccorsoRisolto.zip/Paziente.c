#include <stdio.h>
#include <string.h>
#include "paziente.h"
#include "triage.h"

const char *nomeColore(int codice) {
    switch (codice) {
        case 1: return "ROSSO";
        case 2: return "ARANCIONE";
        case 3: return "GIALLO";
        case 4: return "VERDE";
        default: return "SCONOSCIUTO";
    }
}

int registraPaziente(Paziente lista[], int *n, const char *cognome, const char *nome,
                     int codice, int ora, int minuto) {
    if (*n >= MAX_PAZIENTI) {
        printf("Errore: lista pazienti piena!\n");
        return 0;
    }
    if (codice < 1 || codice > 4) {
        printf("Errore: codice triage non valido (1-4).\n");
        return 0;
    }
    if (ora < 0 || ora > 23 || minuto < 0 || minuto > 59) {
        printf("Errore: orario non valido.\n");
        return 0;
    }

    Paziente *p = &lista[*n];
    strncpy(p->cognome, cognome, 49);
    p->cognome[49] = '\0';
    strncpy(p->nome, nome, 49);
    p->nome[49] = '\0';
    p->codice        = codice;
    p->oraArrivo     = ora;
    p->minutoArrivo  = minuto;
    p->oraFine       = 0;
    p->minutoFine    = 0;
    p->visitato      = 0;

    (*n)++;
    printf("Paziente %s %s registrato con codice %s.\n",
           p->nome, p->cognome, nomeColore(codice));
    return 1;
}

void stampaPaziente(const Paziente *p, int index) {
    printf("[%2d] %-20s %-20s | %s | Arrivo: %02d:%02d | %s\n",
           index + 1,
           p->cognome, p->nome,
           nomeColore(p->codice),
           p->oraArrivo, p->minutoArrivo,
           p->visitato ? "VISITATO" : "IN ATTESA");
}

void stampaListaAttesa(Paziente lista[], int n) {
    if (n == 0) {
        printf("Nessun paziente registrato.\n");
        return;
    }

    /* Copia per ordinare senza modificare l'originale */
    Paziente copia[MAX_PAZIENTI];
    int attesa = 0;
    for (int i = 0; i < n; i++) {
        if (!lista[i].visitato) {
            copia[attesa++] = lista[i];
        }
    }

    if (attesa == 0) {
        printf("Nessun paziente in attesa.\n");
        return;
    }

    /* Ordina la copia per priorita' */
    for (int i = 0; i < attesa - 1; i++) {
        for (int j = i + 1; j < attesa; j++) {
            if (copia[j].codice < copia[i].codice) {
                Paziente tmp = copia[i];
                copia[i] = copia[j];
                copia[j] = tmp;
            }
        }
    }

    printf("\n=== LISTA D'ATTESA (ordine di priorita') ===\n");
    printf("%-4s %-20s %-20s %-10s %-10s %-8s\n",
           "N.", "COGNOME", "NOME", "CODICE", "ARRIVO", "STATO");
    printf("------------------------------------------------------------------------\n");
    for (int i = 0; i < attesa; i++) {
        printf("[%2d] %-20s %-20s | %-9s | %02d:%02d\n",
               i + 1,
               copia[i].cognome, copia[i].nome,
               nomeColore(copia[i].codice),
               copia[i].oraArrivo, copia[i].minutoArrivo);
    }
    printf("Totale in attesa: %d\n\n", attesa);
}

void stampaStatistiche(Paziente lista[], int n) {
    if (n == 0) {
        printf("Nessun dato disponibile.\n");
        return;
    }

    int contatore[5] = {0};      /* indici 1-4 */
    int sommaAttesa[5] = {0};
    int contatoreAttesa[5] = {0};

    for (int i = 0; i < n; i++) {
        int c = lista[i].codice;
        contatore[c]++;
        if (lista[i].visitato) {
            int durata = calcolaDurata(lista[i].oraArrivo, lista[i].minutoArrivo,
                                       lista[i].oraFine,   lista[i].minutoFine);
            sommaAttesa[c] += durata;
            contatoreAttesa[c]++;
        }
    }

    printf("\n=== STATISTICHE PRONTO SOCCORSO ===\n");
    printf("%-12s %-10s %-15s %-15s\n", "CODICE", "TOTALE", "VISITATI", "TEMPO MEDIO");
    printf("----------------------------------------------------\n");
    for (int c = 1; c <= 4; c++) {
        printf("%-12s %-10d %-15d ",
               nomeColore(c), contatore[c], contatoreAttesa[c]);
        if (contatoreAttesa[c] > 0)
            printf("%-10d min\n", sommaAttesa[c] / contatoreAttesa[c]);
        else
            printf("N/D\n");
    }
    printf("----------------------------------------------------\n");
    printf("Totale pazienti: %d\n\n", n);
}