#ifndef PAZIENTE_H
#define PAZIENTE_H

#define MAX_PAZIENTI 100

typedef struct {
    char cognome[50];
    char nome[50];
    int codice;       /* 1=rosso, 2=arancione, 3=giallo, 4=verde */
    int oraArrivo;
    int minutoArrivo;
    int oraFine;
    int minutoFine;
    int visitato;     /* 0=in attesa, 1=visitato */
} Paziente;

/* Registra un nuovo paziente nella lista */
int registraPaziente(Paziente lista[], int *n, const char *cognome, const char *nome,
                     int codice, int ora, int minuto);

/* Stampa un singolo paziente */
void stampaPaziente(const Paziente *p, int index);

/* Stampa la lista d'attesa ordinata per priorita' */
void stampaListaAttesa(Paziente lista[], int n);

/* Stampa statistiche */
void stampaStatistiche(Paziente lista[], int n);

/* Restituisce la stringa del colore dato il codice */
const char *nomeColore(int codice);

#endif