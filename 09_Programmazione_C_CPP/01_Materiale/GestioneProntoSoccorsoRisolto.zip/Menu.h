#ifndef MENU_H
#define MENU_H

#include "paziente.h"

/* Stampa il menu principale */
void stampaMenu(void);

/* Gestisce la registrazione di un nuovo paziente */
void menuRegistra(Paziente lista[], int *n);

/* Gestisce la chiamata del prossimo paziente */
void menuChiamaPaziente(Paziente lista[], int n);

/* Gestisce la registrazione della fine di una visita */
void menuFineVisita(Paziente lista[], int n);

#endif