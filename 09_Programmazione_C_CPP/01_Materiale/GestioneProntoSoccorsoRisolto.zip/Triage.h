#ifndef TRIAGE_H
#define TRIAGE_H

#include "paziente.h"

/* Restituisce il tempo massimo d'attesa in minuti per codice */
int tempoMassimoAttesa(int codice);

/* Calcola la differenza in minuti tra due orari */
int calcolaDurata(int oraIn, int minIn, int oraOut, int minOut);

/*
 * Cerca e restituisce l'indice del prossimo paziente da chiamare
 * (codice piu' basso, non ancora visitato).
 * Restituisce -1 se non ci sono pazienti in attesa.
 */
int prossimoPaziente(Paziente lista[], int n);

/*
 * Chiama il prossimo paziente: lo stampa e ne imposta un flag temporaneo.
 * Restituisce l'indice oppure -1.
 */
int chiamaPaziente(Paziente lista[], int n);

/*
 * Registra la fine della visita per il paziente all'indice dato.
 * Calcola e stampa la durata; emette avviso se supera il massimo previsto.
 */
void registraFineVisita(Paziente lista[], int n, int index, int oraFine, int minutoFine);

#endif