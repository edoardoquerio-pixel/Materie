#ifndef PERSISTENZA_H
#define PERSISTENZA_H

#include "paziente.h"

#define FILE_DATI "pazienti.dat"

/* Salva la lista pazienti su file binario. Restituisce 1 se OK, 0 se errore. */
int salvaDati(const Paziente lista[], int n, const char *nomeFile);

/* Carica la lista pazienti da file binario. Restituisce il numero di pazienti caricati, -1 se errore. */
int caricaDati(Paziente lista[], int maxN, const char *nomeFile);

#endif