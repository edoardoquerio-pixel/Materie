#ifndef PERSISTENZA_H
#define PERSISTENZA_H

#include "parcheggio.h"

int salvaStatoParcheggio(const char nomeFile[],
                         const Parcheggio *parcheggio);

int caricaStatoParcheggio(const char nomeFile[],
                          Parcheggio *parcheggio);

#endif