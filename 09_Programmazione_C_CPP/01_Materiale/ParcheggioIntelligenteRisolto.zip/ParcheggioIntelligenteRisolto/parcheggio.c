#include <stdio.h>
#include <string.h>
#include "parcheggio.h"

void inizializzaParcheggio(Parcheggio *parcheggio, int dimensione) {
    int i;

    parcheggio->dimensione = dimensione;

    for (i = 0; i < parcheggio->dimensione; i++) {
        parcheggio->posti[i].targa[0] = '\0';
        parcheggio->posti[i].oraIngresso = 0;
        parcheggio->posti[i].minutoIngresso = 0;
        parcheggio->posti[i].occupato = 0;
    }
}

void stampaStatoParcheggio(const Parcheggio *parcheggio) {
    int i;

    printf("\n===== STATO PARCHEGGIO =====\n");

    for (i = 0; i < parcheggio->dimensione; i++) {
        if (parcheggio->posti[i].occupato == 1) {
            printf("Posto %d -> OCCUPATO | Targa: %s | Ingresso: %02d:%02d\n",
                   i + 1,
                   parcheggio->posti[i].targa,
                   parcheggio->posti[i].oraIngresso,
                   parcheggio->posti[i].minutoIngresso);
        } else {
            printf("Posto %d -> LIBERO\n", i + 1);
        }
    }
}

int trovaPrimoPostoLibero(const Parcheggio *parcheggio) {
    int i;

    for (i = 0; i < parcheggio->dimensione; i++) {
        if (parcheggio->posti[i].occupato == 0) {
            return i;
        }
    }

    return -1;
}

int cercaVeicoloPerTarga(const Parcheggio *parcheggio, const char targa[]) {
    int i;

    for (i = 0; i < parcheggio->dimensione; i++) {
        if (parcheggio->posti[i].occupato == 1 &&
            strcmp(parcheggio->posti[i].targa, targa) == 0) {
            return i;
        }
    }

    return -1;
}

int registraIngresso(Parcheggio *parcheggio,
                     const char targa[],
                     int ora,
                     int minuto) {
    int indiceLibero;

    if (cercaVeicoloPerTarga(parcheggio, targa) != -1) {
        return -2; /* veicolo già presente */
    }

    indiceLibero = trovaPrimoPostoLibero(parcheggio);

    if (indiceLibero == -1) {
        return -1; /* parcheggio pieno */
    }

    strcpy(parcheggio->posti[indiceLibero].targa, targa);
    parcheggio->posti[indiceLibero].oraIngresso = ora;
    parcheggio->posti[indiceLibero].minutoIngresso = minuto;
    parcheggio->posti[indiceLibero].occupato = 1;

    return indiceLibero;
}

int calcolaDurataMinuti(int oraIngresso,
                        int minutoIngresso,
                        int oraUscita,
                        int minutoUscita) {
    int minutiIngresso;
    int minutiUscita;

    minutiIngresso = oraIngresso * 60 + minutoIngresso;
    minutiUscita = oraUscita * 60 + minutoUscita;

    if (minutiUscita < minutiIngresso) {
        return -1;
    }

    return minutiUscita - minutiIngresso;
}

int calcolaScattiMezzora(int durataMinuti) {
    if (durataMinuti <= 0) {
        return 0;
    }

    return (durataMinuti + 29) / 30;
}

float calcolaCostoSemplice(int durataMinuti,
                           float tariffaOraria) {
    int scattiDa30Minuti;
    float costo;

    if (durataMinuti <= 0) {
        return 0.0f;
    }

    scattiDa30Minuti = calcolaScattiMezzora(durataMinuti);
    costo = scattiDa30Minuti * (tariffaOraria / 2.0f);

    return costo;
}

float calcolaCostoAFasce(int durataMinuti,
                         float tariffaPrimeDueOre,
                         float tariffaOltreDueOre) {
    int scattiTotali;
    int scattiPrimaFascia;
    int scattiSecondaFascia;
    float costoPrimaFascia;
    float costoSecondaFascia;

    scattiTotali = calcolaScattiMezzora(durataMinuti);

    if (scattiTotali <= 4) {
        return scattiTotali * (tariffaPrimeDueOre / 2.0f);
    }

    scattiPrimaFascia = 4;
    scattiSecondaFascia = scattiTotali - 4;

    costoPrimaFascia = scattiPrimaFascia * (tariffaPrimeDueOre / 2.0f);
    costoSecondaFascia = scattiSecondaFascia * (tariffaOltreDueOre / 2.0f);

    return costoPrimaFascia + costoSecondaFascia;
}

int registraUscita(Parcheggio *parcheggio,
                   const char targa[],
                   int oraUscita,
                   int minutoUscita,
                   float tariffaOraria,
                   float *costoCalcolato) {
    int indice;
    int durataMinuti;

    indice = cercaVeicoloPerTarga(parcheggio, targa);

    if (indice == -1) {
        return -1; /* veicolo non trovato */
    }

    durataMinuti = calcolaDurataMinuti(
        parcheggio->posti[indice].oraIngresso,
        parcheggio->posti[indice].minutoIngresso,
        oraUscita,
        minutoUscita
    );

    if (durataMinuti < 0) {
        return -2; /* uscita prima dell'ingresso */
    }

    *costoCalcolato = calcolaCostoSemplice(durataMinuti, tariffaOraria);

    parcheggio->posti[indice].targa[0] = '\0';
    parcheggio->posti[indice].oraIngresso = 0;
    parcheggio->posti[indice].minutoIngresso = 0;
    parcheggio->posti[indice].occupato = 0;

    return durataMinuti;
}

int registraUscitaAFasce(Parcheggio *parcheggio,
                         const char targa[],
                         int oraUscita,
                         int minutoUscita,
                         float tariffaPrimeDueOre,
                         float tariffaOltreDueOre,
                         float *costoCalcolato) {
    int indice;
    int durataMinuti;

    indice = cercaVeicoloPerTarga(parcheggio, targa);

    if (indice == -1) {
        return -1; /* veicolo non trovato */
    }

    durataMinuti = calcolaDurataMinuti(
        parcheggio->posti[indice].oraIngresso,
        parcheggio->posti[indice].minutoIngresso,
        oraUscita,
        minutoUscita
    );

    if (durataMinuti < 0) {
        return -2; /* uscita prima dell'ingresso */
    }

    *costoCalcolato = calcolaCostoAFasce(durataMinuti,
                                         tariffaPrimeDueOre,
                                         tariffaOltreDueOre);

    parcheggio->posti[indice].targa[0] = '\0';
    parcheggio->posti[indice].oraIngresso = 0;
    parcheggio->posti[indice].minutoIngresso = 0;
    parcheggio->posti[indice].occupato = 0;

    return durataMinuti;
}