#ifndef FILE_LOG_H
#define FILE_LOG_H

int scriviLogUscita(const char nomeFile[],
                    const char targa[],
                    int oraIngresso,
                    int minutoIngresso,
                    int oraUscita,
                    int minutoUscita,
                    int durataMinuti,
                    float costo);

#endif