#include <stdio.h>
#include "persistenza.h"

int salvaStatoParcheggio(const char nomeFile[],
                         const Parcheggio *parcheggio) {
    FILE *file;
    size_t elementiScritti;

    file = fopen(nomeFile, "wb");

    if (file == NULL) {
        return 0;
    }

    elementiScritti = fwrite(parcheggio, sizeof(Parcheggio), 1, file);

    fclose(file);

    return (elementiScritti == 1);
}

int caricaStatoParcheggio(const char nomeFile[],
                          Parcheggio *parcheggio) {
    FILE *file;
    size_t elementiLetti;

    file = fopen(nomeFile, "rb");

    if (file == NULL) {
        return 0;
    }

    elementiLetti = fread(parcheggio, sizeof(Parcheggio), 1, file);

    fclose(file);

    return (elementiLetti == 1);
}