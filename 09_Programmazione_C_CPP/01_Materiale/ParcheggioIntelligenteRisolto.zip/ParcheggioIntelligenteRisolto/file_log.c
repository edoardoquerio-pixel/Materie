#include <stdio.h>
#include "file_log.h"

int scriviLogUscita(const char nomeFile[],
                    const char targa[],
                    int oraIngresso,
                    int minutoIngresso,
                    int oraUscita,
                    int minutoUscita,
                    int durataMinuti,
                    float costo) {
    FILE *file;

    file = fopen(nomeFile, "a");

    if (file == NULL) {
        return 0;
    }

    fprintf(file,
            "Targa:%s In:%02d:%02d Out:%02d:%02d Dur:%d Cost:%.2f\n",
            targa,
            oraIngresso,
            minutoIngresso,
            oraUscita,
            minutoUscita,
            durataMinuti,
            costo);

    fclose(file);
    return 1;
}