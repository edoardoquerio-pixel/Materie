#include <stdio.h>
#include <string.h>
#include "parcheggio.h"
#include "utilita.h"
#include "file_log.h"
#include "persistenza.h"

#define NOME_FILE_LOG "log_uscite.txt"
#define NOME_FILE_STATO "stato_parcheggio.dat"

int main() {
    Parcheggio parcheggio;

    int scelta;
    int dimensione;
    int ora;
    int minuto;
    int risultato;
    int indice;
    int usaTariffaAFasce;

    int oraIngressoLog;
    int minutoIngressoLog;

    char targa[LUNGHEZZA_TARGA];
    char targaLog[LUNGHEZZA_TARGA];

    float costo;
    float tariffaOraria = 2.0f;
    float tariffaPrimeDueOre = 2.0f;
    float tariffaOltreDueOre = 1.0f;

    if (caricaStatoParcheggio(NOME_FILE_STATO, &parcheggio)) {
        printf("Stato parcheggio caricato da file.\n");
    } else {
        do {
            dimensione = leggiIntero("Inserisci la dimensione del parcheggio (1-100): ");
            if (dimensione < 1 || dimensione > POSTI_MASSIMI) {
                printf("Dimensione non valida.\n");
            }
        } while (dimensione < 1 || dimensione > POSTI_MASSIMI);

        inizializzaParcheggio(&parcheggio, dimensione);
        printf("Parcheggio inizializzato.\n");
    }

    do {
        printf("\n===== MENU PARCHEGGIO =====\n");
        printf("1. Registra ingresso\n");
        printf("2. Registra uscita\n");
        printf("3. Cerca veicolo per targa\n");
        printf("4. Stampa stato parcheggio\n");
        printf("5. Salva stato parcheggio\n");
        printf("0. Esci\n");

        scelta = leggiIntero("Scelta: ");

        switch (scelta) {
            case 1:
                leggiStringa("Inserisci targa: ", targa, LUNGHEZZA_TARGA);

                if (stringaVuota(targa)) {
                    printf("Targa non valida.\n");
                    break;
                }

                ora = leggiIntero("Ora ingresso: ");
                minuto = leggiIntero("Minuto ingresso: ");

                if (!orarioValido(ora, minuto)) {
                    printf("Orario non valido.\n");
                    break;
                }

                risultato = registraIngresso(&parcheggio, targa, ora, minuto);

                if (risultato == -1) {
                    printf("Parcheggio pieno.\n");
                } else if (risultato == -2) {
                    printf("Veicolo gia' presente nel parcheggio.\n");
                } else {
                    printf("Ingresso registrato al posto %d.\n", risultato + 1);
                }
                break;

            case 2:
                leggiStringa("Inserisci targa: ", targa, LUNGHEZZA_TARGA);

                if (stringaVuota(targa)) {
                    printf("Targa non valida.\n");
                    break;
                }

                indice = cercaVeicoloPerTarga(&parcheggio, targa);

                if (indice == -1) {
                    printf("Veicolo non trovato.\n");
                    break;
                }

                oraIngressoLog = parcheggio.posti[indice].oraIngresso;
                minutoIngressoLog = parcheggio.posti[indice].minutoIngresso;
                strcpy(targaLog, parcheggio.posti[indice].targa);

                ora = leggiIntero("Ora uscita: ");
                minuto = leggiIntero("Minuto uscita: ");

                if (!orarioValido(ora, minuto)) {
                    printf("Orario non valido.\n");
                    break;
                }

                usaTariffaAFasce = leggiIntero("Usare tariffa a fasce? (1 = si, 0 = no): ");

                if (usaTariffaAFasce == 1) {
                    risultato = registraUscitaAFasce(&parcheggio,
                                                     targa,
                                                     ora,
                                                     minuto,
                                                     tariffaPrimeDueOre,
                                                     tariffaOltreDueOre,
                                                     &costo);
                } else {
                    risultato = registraUscita(&parcheggio,
                                               targa,
                                               ora,
                                               minuto,
                                               tariffaOraria,
                                               &costo);
                }

                if (risultato == -1) {
                    printf("Veicolo non trovato.\n");
                } else if (risultato == -2) {
                    printf("Orario uscita precedente all'ingresso.\n");
                } else {
                    printf("Uscita registrata.\n");
                    printf("Durata: %d minuti\n", risultato);
                    printf("Costo: %.2f euro\n", costo);

                    if (!scriviLogUscita(NOME_FILE_LOG,
                                         targaLog,
                                         oraIngressoLog,
                                         minutoIngressoLog,
                                         ora,
                                         minuto,
                                         risultato,
                                         costo)) {
                        printf("Attenzione: errore nella scrittura del log.\n");
                    }
                }
                break;

            case 3:
                leggiStringa("Inserisci targa da cercare: ", targa, LUNGHEZZA_TARGA);

                if (stringaVuota(targa)) {
                    printf("Targa non valida.\n");
                    break;
                }

                risultato = cercaVeicoloPerTarga(&parcheggio, targa);

                if (risultato == -1) {
                    printf("Veicolo non presente.\n");
                } else {
                    printf("Veicolo trovato al posto %d, ingresso alle %02d:%02d\n",
                           risultato + 1,
                           parcheggio.posti[risultato].oraIngresso,
                           parcheggio.posti[risultato].minutoIngresso);
                }
                break;

            case 4:
                stampaStatoParcheggio(&parcheggio);
                break;

            case 5:
                if (salvaStatoParcheggio(NOME_FILE_STATO, &parcheggio)) {
                    printf("Stato parcheggio salvato correttamente.\n");
                } else {
                    printf("Errore nel salvataggio dello stato.\n");
                }
                break;

            case 0:
                if (salvaStatoParcheggio(NOME_FILE_STATO, &parcheggio)) {
                    printf("Stato parcheggio salvato.\n");
                } else {
                    printf("Attenzione: impossibile salvare lo stato del parcheggio.\n");
                }

                printf("Chiusura programma.\n");
                break;

            default:
                printf("Scelta non valida.\n");
        }

    } while (scelta != 0);

    return 0;
}