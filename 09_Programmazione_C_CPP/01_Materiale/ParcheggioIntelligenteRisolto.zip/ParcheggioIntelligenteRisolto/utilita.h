#ifndef UTILITA_H
#define UTILITA_H

int leggiIntero(const char messaggio[]);
void leggiStringa(const char messaggio[], char buffer[], int dimensione);
int orarioValido(int ora, int minuto);
int stringaVuota(const char testo[]);

#endif