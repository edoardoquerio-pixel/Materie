#ifndef PARCHEGGIO_H
#define PARCHEGGIO_H

#define POSTI_MASSIMI 100
#define LUNGHEZZA_TARGA 16

typedef struct {
    char targa[LUNGHEZZA_TARGA];
    int oraIngresso;
    int minutoIngresso;
    int occupato; /* 0 = libero, 1 = occupato */
} Veicolo;

typedef struct {
    Veicolo posti[POSTI_MASSIMI];
    int dimensione; /* numero di posti attivi */
} Parcheggio;

/* inizializzazione e stampa */
void inizializzaParcheggio(Parcheggio *parcheggio, int dimensione);
void stampaStatoParcheggio(const Parcheggio *parcheggio);

/* ricerche */
int trovaPrimoPostoLibero(const Parcheggio *parcheggio);
int cercaVeicoloPerTarga(const Parcheggio *parcheggio, const char targa[]);

/* ingresso */
int registraIngresso(Parcheggio *parcheggio,
                     const char targa[],
                     int ora,
                     int minuto);

/* calcoli */
int calcolaDurataMinuti(int oraIngresso,
                        int minutoIngresso,
                        int oraUscita,
                        int minutoUscita);

int calcolaScattiMezzora(int durataMinuti);

float calcolaCostoSemplice(int durataMinuti,
                           float tariffaOraria);

float calcolaCostoAFasce(int durataMinuti,
                         float tariffaPrimeDueOre,
                         float tariffaOltreDueOre);

/* uscita */
int registraUscita(Parcheggio *parcheggio,
                   const char targa[],
                   int oraUscita,
                   int minutoUscita,
                   float tariffaOraria,
                   float *costoCalcolato);

int registraUscitaAFasce(Parcheggio *parcheggio,
                         const char targa[],
                         int oraUscita,
                         int minutoUscita,
                         float tariffaPrimeDueOre,
                         float tariffaOltreDueOre,
                         float *costoCalcolato);

#endif