#include <stdio.h>
#include <string.h>
#include "utilita.h"

int leggiIntero(const char messaggio[]) {
    int valore;
    int esito;

    do {
        printf("%s", messaggio);
        esito = scanf("%d", &valore);

        if (esito != 1) {
            printf("Input non valido.\n");
            while (getchar() != '\n');
        }
    } while (esito != 1);

    while (getchar() != '\n');
    return valore;
}

void leggiStringa(const char messaggio[], char buffer[], int dimensione) {
    printf("%s", messaggio);
    fgets(buffer, dimensione, stdin);
    buffer[strcspn(buffer, "\n")] = '\0';
}

int orarioValido(int ora, int minuto) {
    return (ora >= 0 && ora <= 23 && minuto >= 0 && minuto <= 59);
}

int stringaVuota(const char testo[]) {
    return testo[0] == '\0';
}