<?php

// ─────────────────────────────────────────────
//  CONFIGURAZIONE CONNESSIONE
// ─────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'its-usr');
define('DB_PASS', 'password');
define('DB_NAME', 'nome_database');

// ─────────────────────────────────────────────
//  CONNESSIONE
// ─────────────────────────────────────────────
try {
    $dsn  = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo  = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Errore di connessione: " . $e->getMessage());
}

// ─────────────────────────────────────────────
//  QUERY
// ─────────────────────────────────────────────
$sql  = "SELECT id, titolo, autore, isbn, pagine, prezzo FROM libri ORDER BY autore ASC";
$stmt = $pdo->query($sql);
$libri = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catalogo Libri</title>

</head>
<body>

    <h1>Catalogo Libri</h1>

    <table border="1">
        <thead>
            <tr>
                <th>#</th>
                <th>Titolo</th>
                <th>Autore</th>
                <th>ISBN</th>
                <th>Pagine</th>
                <th>Prezzo</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($libri) > 0): ?>
                <?php foreach ($libri as $row): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['titolo']) ?></td>
                        <td><?= htmlspecialchars($row['autore']) ?></td>
                        <td><?= htmlspecialchars($row['isbn']) ?></td>
                        <td><?= $row['pagine'] ?></td>
                        <td>€ <?= number_format($row['prezzo'], 2, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Nessun libro trovato nel database.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

<?php
// ─────────────────────────────────────────────
//  CHIUSURA CONNESSIONE
// ─────────────────────────────────────────────
$pdo = null;
?>

</body>
</html>
