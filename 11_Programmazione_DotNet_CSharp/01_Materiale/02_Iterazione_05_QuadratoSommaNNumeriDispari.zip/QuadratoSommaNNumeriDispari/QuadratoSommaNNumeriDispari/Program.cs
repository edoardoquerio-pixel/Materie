﻿/*
1 = 1
4 = 1 + 3
9 = 1 + 3 + 5
16 = 1 + 3 + 5 + 7
25 = 1 + 3 + 5 + 7 + 9
...

Se da input inserisco 11 cosa ottengo?

121 = 1 + 3 + 5 + 7 + 9 + 11 + 13 + 15 + 17 + 19 + 21
 */

Console.Write("Inserisci il numero di cui calcolare il quadrato: ");
int n= int.Parse(Console.ReadLine());

int somma = 0;
string msg = string.Empty;

for(int i = 0; i < n; i++)
{
    somma += 2 * i + 1; //dispari che dipende da i
    // ? : operatore ternario 
    msg += (msg.Length != 0 ? " + " : "") + (2 * i + 1); //costruzione della stringa
}

Console.WriteLine($"{somma} = {msg}");