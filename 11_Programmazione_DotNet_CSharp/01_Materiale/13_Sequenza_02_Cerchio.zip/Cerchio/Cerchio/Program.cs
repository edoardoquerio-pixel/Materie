﻿// Dato in input il lato del cercio,
// calcolare diametro, circonferenza e area
// visualizzare i risultati


Console.Write("Raggio: ");
double raggio = double.Parse(Console.ReadLine());

//calcoli
double diametro = raggio * 2;
double area = raggio * raggio * Math.PI;
double circonferenza = 2*Math.PI*raggio;

//output
//stampa dettaglio
string msg = $"Diametro: {diametro}" +
    $"\nCirconferenza: {circonferenza}" +
    $"\nArea: {area}";

Console.WriteLine(msg); 

