﻿/*
Dati in input due numeri interi
Calcolare il quoziente intero, il resto e il quoziente reale
Visualizzare i risultati 
*/

Console.Write("Dividendo: ");
int a = int.Parse(Console.ReadLine());

Console.Write("Divisore: ");
int b = int.Parse(Console.ReadLine());

//calcoli
int qi = a / b;
int r = a % b; //% => resto di una divisione
double qr = (double)a / b; //casting

//output
Console.WriteLine("{0}/{1}", a, b);
Console.WriteLine("Quoziente intero: {0}",qi);
Console.WriteLine("Resto: {0}",r);
Console.WriteLine("Quoziente reale: {0}",qr);
