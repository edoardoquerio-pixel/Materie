﻿/*
 Dato in input un numero intero [1,7]
Visualizzare il nome del relativo giorno della settimana

es. 2 => martedì

es. 9 => errore
*/

Console.Write("Numero [1,7]: ");
int n = int.Parse(Console.ReadLine());

switch (n)
{
    case 1: Console.WriteLine("lunedì"); break;
    case 2: Console.WriteLine("martedì"); break;
    case 3: Console.WriteLine("mercoledì"); break;
    case 4: Console.WriteLine("giovedì"); break;
    case 5: Console.WriteLine("venerdì"); break;
    case 6: Console.WriteLine("sabato"); break;
    case 7: Console.WriteLine("domenica"); break;
    default: Console.WriteLine("errore"); break;
}