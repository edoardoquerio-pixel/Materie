﻿namespace GuiPersona
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNuovo = new System.Windows.Forms.Label();
            this.lblCognome = new System.Windows.Forms.Label();
            this.txtCognome = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtDataNascita = new System.Windows.Forms.TextBox();
            this.lblDataNascita = new System.Windows.Forms.Label();
            this.txtLuogoNascita = new System.Windows.Forms.TextBox();
            this.lblLuogoNascita = new System.Windows.Forms.Label();
            this.lblSesso = new System.Windows.Forms.Label();
            this.btnInvia = new System.Windows.Forms.Button();
            this.btnCancella = new System.Windows.Forms.Button();
            this.lblEta = new System.Windows.Forms.Label();
            this.txtEta = new System.Windows.Forms.TextBox();
            this.cbxSesso = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblNuovo
            // 
            this.lblNuovo.AutoSize = true;
            this.lblNuovo.Location = new System.Drawing.Point(256, 20);
            this.lblNuovo.Name = "lblNuovo";
            this.lblNuovo.Size = new System.Drawing.Size(39, 13);
            this.lblNuovo.TabIndex = 0;
            this.lblNuovo.Text = "Nuovo";
            // 
            // lblCognome
            // 
            this.lblCognome.AutoSize = true;
            this.lblCognome.Location = new System.Drawing.Point(54, 78);
            this.lblCognome.Name = "lblCognome";
            this.lblCognome.Size = new System.Drawing.Size(52, 13);
            this.lblCognome.TabIndex = 1;
            this.lblCognome.Text = "Cognome";
            // 
            // txtCognome
            // 
            this.txtCognome.Location = new System.Drawing.Point(140, 71);
            this.txtCognome.Name = "txtCognome";
            this.txtCognome.Size = new System.Drawing.Size(100, 20);
            this.txtCognome.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(140, 119);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 4;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(54, 126);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 3;
            this.lblNome.Text = "Nome";
            // 
            // txtDataNascita
            // 
            this.txtDataNascita.Location = new System.Drawing.Point(140, 173);
            this.txtDataNascita.Name = "txtDataNascita";
            this.txtDataNascita.Size = new System.Drawing.Size(100, 20);
            this.txtDataNascita.TabIndex = 6;
            // 
            // lblDataNascita
            // 
            this.lblDataNascita.AutoSize = true;
            this.lblDataNascita.Location = new System.Drawing.Point(54, 180);
            this.lblDataNascita.Name = "lblDataNascita";
            this.lblDataNascita.Size = new System.Drawing.Size(80, 13);
            this.lblDataNascita.TabIndex = 5;
            this.lblDataNascita.Text = "Data di Nascita";
            // 
            // txtLuogoNascita
            // 
            this.txtLuogoNascita.Location = new System.Drawing.Point(140, 221);
            this.txtLuogoNascita.Name = "txtLuogoNascita";
            this.txtLuogoNascita.Size = new System.Drawing.Size(100, 20);
            this.txtLuogoNascita.TabIndex = 8;
            // 
            // lblLuogoNascita
            // 
            this.lblLuogoNascita.AutoSize = true;
            this.lblLuogoNascita.Location = new System.Drawing.Point(54, 228);
            this.lblLuogoNascita.Name = "lblLuogoNascita";
            this.lblLuogoNascita.Size = new System.Drawing.Size(87, 13);
            this.lblLuogoNascita.TabIndex = 7;
            this.lblLuogoNascita.Text = "Luogo di Nascita";
            // 
            // lblSesso
            // 
            this.lblSesso.AutoSize = true;
            this.lblSesso.Location = new System.Drawing.Point(54, 283);
            this.lblSesso.Name = "lblSesso";
            this.lblSesso.Size = new System.Drawing.Size(36, 13);
            this.lblSesso.TabIndex = 9;
            this.lblSesso.Text = "Sesso";
            // 
            // btnInvia
            // 
            this.btnInvia.Location = new System.Drawing.Point(103, 343);
            this.btnInvia.Name = "btnInvia";
            this.btnInvia.Size = new System.Drawing.Size(75, 23);
            this.btnInvia.TabIndex = 11;
            this.btnInvia.Text = "Invia";
            this.btnInvia.UseVisualStyleBackColor = true;
            this.btnInvia.Click += new System.EventHandler(this.btnInvia_Click);
            // 
            // btnCancella
            // 
            this.btnCancella.Location = new System.Drawing.Point(203, 343);
            this.btnCancella.Name = "btnCancella";
            this.btnCancella.Size = new System.Drawing.Size(75, 23);
            this.btnCancella.TabIndex = 12;
            this.btnCancella.Text = "Cancella";
            this.btnCancella.UseVisualStyleBackColor = true;
            this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
            // 
            // lblEta
            // 
            this.lblEta.AutoSize = true;
            this.lblEta.Location = new System.Drawing.Point(81, 470);
            this.lblEta.Name = "lblEta";
            this.lblEta.Size = new System.Drawing.Size(23, 13);
            this.lblEta.TabIndex = 13;
            this.lblEta.Text = "Età";
            // 
            // txtEta
            // 
            this.txtEta.Enabled = false;
            this.txtEta.Location = new System.Drawing.Point(128, 470);
            this.txtEta.Name = "txtEta";
            this.txtEta.Size = new System.Drawing.Size(100, 20);
            this.txtEta.TabIndex = 14;
            // 
            // cbxSesso
            // 
            this.cbxSesso.FormattingEnabled = true;
            this.cbxSesso.Items.AddRange(new object[] {
            "F",
            "M"});
            this.cbxSesso.Location = new System.Drawing.Point(140, 283);
            this.cbxSesso.Name = "cbxSesso";
            this.cbxSesso.Size = new System.Drawing.Size(121, 21);
            this.cbxSesso.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 597);
            this.Controls.Add(this.cbxSesso);
            this.Controls.Add(this.txtEta);
            this.Controls.Add(this.lblEta);
            this.Controls.Add(this.btnCancella);
            this.Controls.Add(this.btnInvia);
            this.Controls.Add(this.lblSesso);
            this.Controls.Add(this.txtLuogoNascita);
            this.Controls.Add(this.lblLuogoNascita);
            this.Controls.Add(this.txtDataNascita);
            this.Controls.Add(this.lblDataNascita);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtCognome);
            this.Controls.Add(this.lblCognome);
            this.Controls.Add(this.lblNuovo);
            this.Name = "Form1";
            this.Text = "GUI Persona";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNuovo;
        private System.Windows.Forms.Label lblCognome;
        private System.Windows.Forms.TextBox txtCognome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtDataNascita;
        private System.Windows.Forms.Label lblDataNascita;
        private System.Windows.Forms.TextBox txtLuogoNascita;
        private System.Windows.Forms.Label lblLuogoNascita;
        private System.Windows.Forms.Label lblSesso;
        private System.Windows.Forms.Button btnInvia;
        private System.Windows.Forms.Button btnCancella;
        private System.Windows.Forms.Label lblEta;
        private System.Windows.Forms.TextBox txtEta;
        private System.Windows.Forms.ComboBox cbxSesso;
    }
}

