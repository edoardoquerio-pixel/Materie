﻿using ClassePersona;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiPersona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInvia_Click(object sender, EventArgs e)
        {
            var p = new Persona(txtNome.Text,txtCognome.Text,DateTime.Parse(txtDataNascita.Text),txtLuogoNascita.Text);

            txtEta.Text=p.Eta().ToString();


        }

        private void ResetForm()
        {
            txtCognome.Text = string.Empty;
            txtNome.Text = string.Empty;
            txtDataNascita.Text = string.Empty;
            txtLuogoNascita.Text=string.Empty;
            cbxSesso.SelectedIndex = -1;
            txtEta.Text = string.Empty;
        }

        private void btnCancella_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Conferma cancella dati?", "Conferma", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                ResetForm();
        }
    }
}
