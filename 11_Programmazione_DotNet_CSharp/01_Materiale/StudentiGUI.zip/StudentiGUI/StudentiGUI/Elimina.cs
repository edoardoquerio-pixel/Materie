﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StudentiGUI
{
    public partial class Elimina : Form
    {
        private Studente? studente;
        public Elimina()
        {
            InitializeComponent();
        }

        private void btnCerca_Click(object sender, EventArgs e)
        {
            int matricola = Convert.ToInt32(txtCerca.Text);

            var dal = new StudentiDAL();

            studente = dal.Dettaglio(matricola);

            if (studente == null)
                MessageBox.Show($"Lo studente con matricola {matricola} non esiste", "Cerca", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                txtMatricola.Text = studente.Matricola.ToString();
                txtNome.Text = studente.Nome;
                txtCognome.Text = studente.Cognome;
                txtEmail.Text = studente.Email;
                txtClasse.Text = studente.Classe;
            }
        }

        private void btnSalva_Click(object sender, EventArgs e)
        {
            var dal = new StudentiDAL();

            if (studente != null)
                if (MessageBox.Show($"Eliminare lo studente con matricola {studente.Matricola}?", "Cancella", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    dal.Elimina(studente);
                    ResetForm();
                }
        }
        private void ResetForm()
        {
            txtMatricola.Text = string.Empty;
            txtNome.Text = string.Empty;
            txtCognome.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtClasse.Text = string.Empty;
        }

        private void btnCancella_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show($"Eliminare tutti i dati del form?", "Cancella", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                ResetForm();
        }
    }
}
