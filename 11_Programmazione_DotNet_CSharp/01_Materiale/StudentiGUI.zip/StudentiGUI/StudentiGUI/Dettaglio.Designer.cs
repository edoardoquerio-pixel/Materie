﻿namespace StudentiGUI
{
    partial class Dettaglio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitolo = new Label();
            lblCerca = new Label();
            txtCerca = new TextBox();
            btnCerca = new Button();
            pnlCerca = new Panel();
            pnlDettaglio = new Panel();
            txtClasse = new TextBox();
            lblClasse = new Label();
            txtEmail = new TextBox();
            lblEmail = new Label();
            txtCognome = new TextBox();
            lblCognome = new Label();
            txtNome = new TextBox();
            lblNome = new Label();
            txtMatricola = new TextBox();
            lblMatricola = new Label();
            pnlCerca.SuspendLayout();
            pnlDettaglio.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitolo
            // 
            lblTitolo.AutoSize = true;
            lblTitolo.Location = new Point(174, 9);
            lblTitolo.Name = "lblTitolo";
            lblTitolo.Size = new Size(105, 15);
            lblTitolo.TabIndex = 0;
            lblTitolo.Text = "Dettaglio Studente";
            // 
            // lblCerca
            // 
            lblCerca.AutoSize = true;
            lblCerca.Location = new Point(50, 46);
            lblCerca.Name = "lblCerca";
            lblCerca.Size = new Size(110, 15);
            lblCerca.TabIndex = 1;
            lblCerca.Text = "Cerca per Matricola";
            // 
            // txtCerca
            // 
            txtCerca.Location = new Point(177, 42);
            txtCerca.Name = "txtCerca";
            txtCerca.Size = new Size(100, 23);
            txtCerca.TabIndex = 2;
            // 
            // btnCerca
            // 
            btnCerca.Location = new Point(307, 41);
            btnCerca.Name = "btnCerca";
            btnCerca.Size = new Size(75, 23);
            btnCerca.TabIndex = 3;
            btnCerca.Text = "Cerca";
            btnCerca.UseVisualStyleBackColor = true;
            btnCerca.Click += btnCerca_Click;
            // 
            // pnlCerca
            // 
            pnlCerca.Controls.Add(btnCerca);
            pnlCerca.Controls.Add(lblCerca);
            pnlCerca.Controls.Add(txtCerca);
            pnlCerca.Location = new Point(12, 27);
            pnlCerca.Name = "pnlCerca";
            pnlCerca.Size = new Size(460, 100);
            pnlCerca.TabIndex = 4;
            // 
            // pnlDettaglio
            // 
            pnlDettaglio.Controls.Add(txtClasse);
            pnlDettaglio.Controls.Add(lblClasse);
            pnlDettaglio.Controls.Add(txtEmail);
            pnlDettaglio.Controls.Add(lblEmail);
            pnlDettaglio.Controls.Add(txtCognome);
            pnlDettaglio.Controls.Add(lblCognome);
            pnlDettaglio.Controls.Add(txtNome);
            pnlDettaglio.Controls.Add(lblNome);
            pnlDettaglio.Controls.Add(txtMatricola);
            pnlDettaglio.Controls.Add(lblMatricola);
            pnlDettaglio.Location = new Point(12, 133);
            pnlDettaglio.Name = "pnlDettaglio";
            pnlDettaglio.Size = new Size(460, 395);
            pnlDettaglio.TabIndex = 5;
            // 
            // txtClasse
            // 
            txtClasse.Enabled = false;
            txtClasse.Location = new Point(107, 238);
            txtClasse.Name = "txtClasse";
            txtClasse.Size = new Size(100, 23);
            txtClasse.TabIndex = 9;
            // 
            // lblClasse
            // 
            lblClasse.AutoSize = true;
            lblClasse.Location = new Point(44, 246);
            lblClasse.Name = "lblClasse";
            lblClasse.Size = new Size(40, 15);
            lblClasse.TabIndex = 8;
            lblClasse.Text = "Classe";
            // 
            // txtEmail
            // 
            txtEmail.Enabled = false;
            txtEmail.Location = new Point(107, 189);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 7;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(44, 197);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(36, 15);
            lblEmail.TabIndex = 6;
            lblEmail.Text = "Email";
            // 
            // txtCognome
            // 
            txtCognome.Enabled = false;
            txtCognome.Location = new Point(107, 127);
            txtCognome.Name = "txtCognome";
            txtCognome.Size = new Size(100, 23);
            txtCognome.TabIndex = 5;
            // 
            // lblCognome
            // 
            lblCognome.AutoSize = true;
            lblCognome.Location = new Point(44, 135);
            lblCognome.Name = "lblCognome";
            lblCognome.Size = new Size(60, 15);
            lblCognome.TabIndex = 4;
            lblCognome.Text = "Cognome";
            // 
            // txtNome
            // 
            txtNome.Enabled = false;
            txtNome.Location = new Point(107, 71);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 3;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(44, 79);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 2;
            lblNome.Text = "Nome";
            // 
            // txtMatricola
            // 
            txtMatricola.Enabled = false;
            txtMatricola.Location = new Point(107, 23);
            txtMatricola.Name = "txtMatricola";
            txtMatricola.Size = new Size(100, 23);
            txtMatricola.TabIndex = 1;
            // 
            // lblMatricola
            // 
            lblMatricola.AutoSize = true;
            lblMatricola.Location = new Point(44, 31);
            lblMatricola.Name = "lblMatricola";
            lblMatricola.Size = new Size(57, 15);
            lblMatricola.TabIndex = 0;
            lblMatricola.Text = "Matricola";
            // 
            // Dettaglio
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(484, 561);
            Controls.Add(pnlDettaglio);
            Controls.Add(pnlCerca);
            Controls.Add(lblTitolo);
            Name = "Dettaglio";
            Text = "Dettaglio";
            pnlCerca.ResumeLayout(false);
            pnlCerca.PerformLayout();
            pnlDettaglio.ResumeLayout(false);
            pnlDettaglio.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitolo;
        private Label lblCerca;
        private TextBox txtCerca;
        private Button btnCerca;
        private Panel pnlCerca;
        private Panel pnlDettaglio;
        private TextBox txtMatricola;
        private Label lblMatricola;
        private TextBox txtClasse;
        private Label lblClasse;
        private TextBox txtEmail;
        private Label lblEmail;
        private TextBox txtCognome;
        private Label lblCognome;
        private TextBox txtNome;
        private Label lblNome;
    }
}