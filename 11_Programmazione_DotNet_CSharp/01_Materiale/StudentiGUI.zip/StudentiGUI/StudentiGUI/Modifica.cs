﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StudentiGUI
{
    public partial class Modifica : Form
    {
        public Modifica()
        {
            InitializeComponent();
        }

        private void btnCerca_Click(object sender, EventArgs e)
        {
            //istanziare oggetto dal
            var dal = new StudentiDAL();

            int matricola = Convert.ToInt32(txtCerca.Text);
            //cerco studente con matricola
            Studente? s = dal.Dettaglio(matricola);

            if (s == null)
                MessageBox.Show($"Lo studente con matricola {matricola} non esiste", "Cerca", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                txtMatricola.Text = s.Matricola.ToString();
                txtNome.Text = s.Nome;
                txtCognome.Text = s.Cognome;
                txtEmail.Text = s.Email;
                txtClasse.Text = s.Classe;
            }

        }

        private void btnSalva_Click(object sender, EventArgs e)
        {

            //istanziare oggetto dal
            var dal = new StudentiDAL();

                //salvo i dati nel database
                var studente = new Studente()
                {
                    Matricola = Convert.ToInt32(txtMatricola.Text),
                    Nome = txtNome.Text,
                    Cognome = txtCognome.Text,
                    Email = txtEmail.Text,
                    Classe = txtClasse.Text
                };

                dal.Modifica(studente);
                MessageBox.Show($"Operazione eseguita con successo", "Modifica", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetForm();
            }

        

        private void ResetForm()
        {
            txtMatricola.Text = string.Empty;
            txtNome.Text = string.Empty;
            txtCognome.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtClasse.Text = string.Empty;
        }

        private void btnCancella_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show($"Eliminare tutti i dati del form?", "Cancella", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                ResetForm();
        }
    }
}
