﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StudentiGUI
{
    public partial class Nuovo : Form
    {
        public Nuovo()
        {
            InitializeComponent();
        }

        private void btnSalva_Click(object sender, EventArgs e)
        {
            //istanziare oggetto dal
            var dal = new StudentiDAL();

            int matricola = Convert.ToInt32(txtMatricola.Text);
            //cerco studente con matricola
            Studente? s = dal.Dettaglio(matricola);

            //verifico sua assenza nel database
            if (s != null)
                MessageBox.Show($"Matricola {matricola} già presente nel database", "Cerca", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else {

                //salvo i dati nel database
                var studente = new Studente()
                {
                    Matricola = matricola,
                    Nome = txtNome.Text,
                    Cognome = txtCognome.Text,
                    Email = txtEmail.Text,
                    Classe = txtClasse.Text
                };

                dal.Nuovo(studente);
                MessageBox.Show($"Operazione eseguita con successo", "Nuovo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetForm();
            }

        }

        private void ResetForm() {

            txtMatricola.Text = string.Empty;
            txtNome.Text = string.Empty;
            txtCognome.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtClasse.Text = string.Empty;        
        }

        private void btnCancella_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show($"Eliminare tutti i dati del form?", "Cancella", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                ResetForm();
        }
    }
}
