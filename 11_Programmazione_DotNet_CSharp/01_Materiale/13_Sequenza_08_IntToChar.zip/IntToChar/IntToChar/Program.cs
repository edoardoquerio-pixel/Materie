﻿// Dato in input un numero intero [32,127]
//visualizzare il carattere corrispondente in ASCII stardard

Console.Write("Inserisci un numero intero da tastiera [32,127]: ");
int posizione = int.Parse(Console.ReadLine());

char c = (char)posizione;
Console.WriteLine("posizione ASCII: {0} corrisponde al carattere {1}",posizione, c);

