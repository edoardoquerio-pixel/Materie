import express from 'express';
import bodyParser from 'body-parser';
import sqlite3 from 'sqlite3';
import { CREATE_LIBRI_TABLE } from './database/script_libri.js';
import libriRouter from './routes/libriRouter.js';


const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use("/api/v2/libri", libriRouter);

export const db = new sqlite3.Database("./database/libreria.db");

app.listen(port, () => {
    console.log(`Il server è attivo sulla porta ${port}`);
    initializeDatabase();
});



function initializeDatabase() {
    console.log("Inizializzazione del database...");

    db.exec(CREATE_LIBRI_TABLE, (err) => {
        if (err) {
            console.error("Errore durante la creazione della tabella libri:", err.message);
        } else {
            console.log("Tabella libri inizializzata correttamente.");
        }
    });
}