import express from 'express';
import bodyParser from 'body-parser';
import catalogoLibri from './model/catalogo.js';
import clientiFile from './model/clienti.js';


const app = express();
app.use(bodyParser.json());
const PORT = 3000;
const BASE_PATH = "/api/v1";

var catalogo = [...catalogoLibri];
var clienti = [...clientiFile];

// avvia il server
app.listen(PORT, () => {
    console.log("Server attivo sulla porta " + PORT);
});

// endpoint per restituire un testo di prova
app.get("/", (req, res) => {
    res.send("Benvenuto nella tua libreria online!");
});

// endpoint per recuperare l'intero catalogo dei libri
app.get(BASE_PATH + "/libri", (req, res) => {
    res.json(catalogo);
});

// endpoint per recuperare l'intero elenco dei clienti
app.get(BASE_PATH + "/clienti", (req, res) => {
    res.json(clienti);
});

// endpoint per aggiungere un nuovo libro al catalogo
app.post(`${BASE_PATH}/libri`, (req, res) => {
    const nuovoLibro = req.body;

    if (!nuovoLibro) {
        res.status(400).json({ error: "Body non presente" });
        return;
    }
    // possibile alternativa: usare destructuring syntax
    if (!nuovoLibro.titolo || !nuovoLibro.genere || !nuovoLibro.autore || !nuovoLibro.editore || !nuovoLibro.numeroPagine) {
        res.status(400).json({ error: 'Dati del libro incompleti' });
        return;
    }

    // assegno un id univoco; normalmente questa operazione la farebbe il database sottostante
    const maxId = catalogo.map(item => item.id)
                          .reduce((a, b) => Math.max(a, b), 0);
    nuovoLibro.id = maxId + 1;

    console.log("Aggiungo il libro: " + JSON.stringify(nuovoLibro));
    catalogo.push(nuovoLibro);
    res.status(201).json(nuovoLibro);
});