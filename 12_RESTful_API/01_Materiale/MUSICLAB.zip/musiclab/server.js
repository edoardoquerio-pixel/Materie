import express from "express";
import path from "path";
import songsRouter from "./routes/songs.js";
import playlistsRouter from "./routes/playlists.js";

const app  = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(path.resolve(), "frontend")));

app.use("/songs",     songsRouter);
app.use("/playlists", playlistsRouter);

app.listen(PORT, () => {
  console.log(`✅ Server avviato su http://localhost:${PORT}`);
});
