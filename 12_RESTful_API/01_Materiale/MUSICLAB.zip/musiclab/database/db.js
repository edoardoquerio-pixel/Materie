import sqlite3 from 'sqlite3';

const db = new sqlite3.Database("./database/musiclab.db");

// Inizializzazione del database: crea le tabelle se non esistono
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS songs (
      id      INTEGER PRIMARY KEY AUTOINCREMENT,
      title   TEXT    NOT NULL,
      artist  TEXT    NOT NULL,
      album   TEXT,
      genre   TEXT,
      year    INTEGER
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS playlists (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT NOT NULL,
      description TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS playlist_songs (
      playlist_id INTEGER NOT NULL,
      song_id     INTEGER NOT NULL,
      PRIMARY KEY (playlist_id, song_id)
    )
  `);

  // Dati di esempio — inseriti solo se il database è vuoto
  db.get("SELECT COUNT(*) as n FROM songs", (err, row) => {
    if (row.n > 0) return;

    const insert = db.prepare(
      "INSERT INTO songs (title, artist, album, genre, year) VALUES (?, ?, ?, ?, ?)"
    );
    [
      ["Bohemian Rhapsody",     "Queen",           "A Night at the Opera", "Rock",     1975],
      ["Hotel California",      "Eagles",           "Hotel California",     "Rock",     1977],
      ["Smells Like Teen Spirit","Nirvana",         "Nevermind",            "Grunge",   1991],
      ["Billie Jean",           "Michael Jackson",  "Thriller",             "Pop",      1982],
      ["Superstition",          "Stevie Wonder",    "Talking Book",         "Soul",     1972],
      ["Lose Yourself",         "Eminem",           "8 Mile Soundtrack",    "Rap",      2002],
      ["Clair de Lune",         "Debussy",          "Suite bergamasque",    "Classica", 1905],
      ["Shape of You",          "Ed Sheeran",       "÷",                    "Pop",      2017],
    ].forEach((row) => insert.run(...row));

    insert.finalize();
  });
});


export default db;
