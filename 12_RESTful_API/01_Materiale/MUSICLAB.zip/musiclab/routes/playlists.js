import express from "express";
import db from "../database/db.js";

const router = express.Router();


// GET /playlists
router.get("/", (req, res) => {
  console.log(`GET /playlists`);
  db.all("SELECT * FROM playlists", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});


// GET /playlists/:id  (con brani associati)
router.get("/:id", (req, res) => {
  console.log(`GET /playlists/${req.params.id}`);
  const { id } = req.params;

  db.get("SELECT * FROM playlists WHERE id = ?", [id], (err, playlist) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!playlist) return res.status(404).json({ error: "Playlist non trovata" });

    db.all(
      `SELECT songs.*
       FROM playlist_songs
       JOIN songs ON songs.id = playlist_songs.song_id
       WHERE playlist_songs.playlist_id = ?`,
      [id],
      (err, songs) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ ...playlist, songs });
      }
    );
  });
});


// POST /playlists
router.post("/", (req, res) => {
  console.log(`POST /playlists`, req.body);
  const { name, description } = req.body;

  const errorMessage = validatePlaylist(req.body);
  if (errorMessage) return res.status(400).json({ error: errorMessage });

  db.run("INSERT INTO playlists (name, description) VALUES (?, ?)", [name, description],
    (err, lastID) => {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json({ message: `Playlist creata con id ${lastID}` });
    });
});


// PUT /playlists/:id
router.put("/:id", (req, res) => {
  console.log(`PUT /playlists/${req.params.id}`, req.body);
  const { id } = req.params;
  const { name, description } = req.body;

  const errorMessage = validatePlaylist(req.body);
  if (errorMessage) return res.status(400).json({ error: errorMessage });

  db.run("UPDATE playlists SET name = ?, description = ? WHERE id = ?", [name, description, id], (err, changes) => {
      if (err) return res.status(500).json({ error: err.message });
      if (changes === 0) return res.status(404).json({ error: "Playlist non trovata" });
      res.json({ message: "Playlist aggiornata con successo" });
    }
  );

});


// DELETE /playlists/:id
router.delete("/:id", (req, res) => {
  console.log(`DELETE /playlists/${req.params.id}`);
  const { id } = req.params;

  // Controllo che la playlist esista prima di tentare di eliminarla
  db.get("SELECT * FROM playlists WHERE id = ?", [id], (err, existing) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!existing) return res.status(404).json({ error: "Playlist non trovata" });

    // Elimina prima le associazioni con i brani, poi la playlist stessa
    db.run("DELETE FROM playlist_songs WHERE playlist_id = ?", [id], (err) => {
      if (err) return res.status(500).json({ error: err.message });

      db.run("DELETE FROM playlists WHERE id = ?", [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Playlist eliminata" });
      });
    });
  });
});


// POST /playlists/:id/songs
// Aggiunge un brano alla playlist specificata creando una nuova associazione nella tabella playlist_songs
router.post("/:id/songs", (req, res) => {
  console.log(`POST /playlists/${req.params.id}/songs`, req.body);
  const { id } = req.params;
  const { song_id } = req.body;


  // Controllo che la playlist e il brano esistano, e che l'associazione non esista già, prima di creare la nuova associazione
  db.get("SELECT * FROM playlists WHERE id = ?", [id], (err, playlist) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!playlist) return res.status(404).json({ error: "Playlist non trovata" });

    db.get("SELECT * FROM songs WHERE id = ?", [song_id], (err, song) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!song) return res.status(404).json({ error: "Brano non trovato" });

      db.get(
        "SELECT * FROM playlist_songs WHERE playlist_id = ? AND song_id = ?",
        [id, song_id],
        (err, existing) => {
          if (err) return res.status(500).json({ error: err.message });
          if (existing) return res.status(409).json({ error: "Brano già presente nella playlist" });

          db.run(
            "INSERT INTO playlist_songs (playlist_id, song_id) VALUES (?, ?)",
            [id, song_id],
            (err) => {
              if (err) return res.status(500).json({ error: err.message });
              res.status(201).json({ message: "Brano aggiunto alla playlist" });
            }
          );
        }
      );
    });
  });
});


// DELETE /playlists/:id/songs/:songId
// Rimuove un brano dalla playlist specificata eliminando l'associazione corrispondente nella tabella playlist_songs
router.delete("/:id/songs/:songId", (req, res) => {
  console.log(`DELETE /playlists/${req.params.id}/songs/${req.params.songId}`);
  const { id, songId } = req.params;

  db.get(
    "SELECT * FROM playlist_songs WHERE playlist_id = ? AND song_id = ?",
    [id, songId],
    (err, existing) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!existing) return res.status(404).json({ error: "Brano non presente nella playlist" });

      db.run(
        "DELETE FROM playlist_songs WHERE playlist_id = ? AND song_id = ?",
        [id, songId],
        (err) => {
          if (err) return res.status(500).json({ error: err.message });
          res.json({ message: "Brano rimosso dalla playlist" });
        }
      );
    }
  );
});


function validatePlaylist(playlist) {
  let errorMessage = null;

  if (!playlist) {
    errorMessage = "Playlist mancante";
  }
  if (!playlist.name) {
    errorMessage = "name è obbligatorio";
  }

  return errorMessage;
}


export default router;
