import express from "express";
import db from "../database/db.js";

const router = express.Router();


// GET /songs  (con filtri opzionali ?title= e/o ?artist=)
router.get("/", (req, res) => {
  const { title, artist } = req.query;
  console.log(`GET /songs?title=${title}&artist=${artist}`);

  const conditions = [];
  const params = [];

  // uso due array per le condizioni della WEHERE e per i relativi parametri, in modo da poter gestire dinamicamente la presenza o meno dei filtri
  if (title) {
    conditions.push("LOWER(title) LIKE LOWER(?)");
    params.push(`%${title}%`);
  }
  if (artist) {
    conditions.push("LOWER(artist) LIKE LOWER(?)");
    params.push(`%${artist}%`);
  }

  // se ci sono condizioni, aggiungo la clausola WHERE e, se ce n'è più di una, le unisco con AND; se non ci sono condizioni, restituisco stringa vuota
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  // costruisco la query finale
  const sql = `SELECT * FROM songs ${where}`;

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});


// GET /songs/:id
router.get("/:id", (req, res) => {
  console.log(`GET /songs/${req.params.id}`);

  db.get("SELECT * FROM songs WHERE id = ?", [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: "Brano non trovato" });
    res.json(row);
  });
});


// POST /songs
router.post("/", (req, res) => {
  console.log(`POST /songs`, req.body);
  const { title, artist, album, genre, year } = req.body;

  const errorMessage = validateSong(req.body);
  if (errorMessage) {
    res.status(400).json({ error: errorMessage });
    return;
  }

  db.run(
    "INSERT INTO songs (title, artist, album, genre, year) VALUES (?, ?, ?, ?, ?)", [title, artist, album, genre, year], (err, lastID) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      } else {
        res.status(201).json({ message: `Brano creato con id ${lastID}` });
      }
    }
  );
});


// PUT /songs/:id
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { title, artist, album, genre, year } = req.body;
  console.log(`PUT /songs/${id}`, req.body);

  const errorMessage = validateSong(req.body);
  if (errorMessage) {
    res.status(400).json({ error: errorMessage });
    return;
  }

  db.run("UPDATE songs SET title=?, artist=?, album=?, genre=?, year=? WHERE id=?", [title, artist, album, genre, year, id], (err, changes) => {
    if (err) return res.status(500).json({ error: err.message });
    if (changes === 0) return res.status(404).json({ error: "Brano non trovato" });
    res.json({ message: "Brano aggiornato con successo" });
  });
});


// DELETE /songs/:id
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  console.log(`DELETE /songs/${id}`);

  db.get("SELECT * FROM songs WHERE id = ?", [id], (err, existing) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!existing) return res.status(404).json({ error: "Brano non trovato" });

    db.run("DELETE FROM playlist_songs WHERE song_id = ?", [id], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      
      db.run("DELETE FROM songs WHERE id = ?", [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Brano eliminato" });
      });
    });
  });
});



function validateSong(song) {
  let errorMessage = null;
  
  if (!song) {
    errorMessage = "Brano mancante";
  }
  if (!song.title || !song.artist) {
    errorMessage = "Title e Artist sono obbligatori";
  }

  return errorMessage;
}



export default router;